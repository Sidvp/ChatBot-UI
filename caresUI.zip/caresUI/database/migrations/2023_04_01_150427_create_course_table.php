<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCourseTable extends Migration
{
    /*** Run the migrations. ** @return void */
    public function up()
    {
        Schema::create('course', function (Blueprint $table) {
            $table->id('course_id');   
            $table->enum('class',["VI","VII","VIII"]);
            $table->enum('curriculum',["REGULAR","ELECTIVE"]);

            $table->timestamps();  // created_at, updated_at 
        });
    }

    /*** Reverse the migrations. ** @return void */
    public function down()
    {
        Schema::dropIfExists('course');
    }
}





 // $table->string('name', 60);
            // $table->string('email', 100);
            // $table->enum('gender',["M","F","Other"])->nullable();
            // $table->text('address');
            // $table->date('dob')->nullable();
            // $table->string('password');
            // $table->boolean('status')->default(1);
            // $table->integer('points')->default(0);
