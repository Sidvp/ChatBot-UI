<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStudentsTable extends Migration
{
    /*** Run the migrations. ** @return void */
    public function up()
    {
        Schema::create('students', function (Blueprint $table) {
            $table->id('student_id');  
            $table->string('name', 60);
            $table->string('email', 100)->unique();
            $table->string('school_name', 200);
            $table->string('class', 200);
            $table->string('username', 60);
            $table->string('password');
            $table->timestamps();
        });
    }

    /*** Reverse the migrations. ** @return void */
    public function down()
    {
        Schema::dropIfExists('students');
    }
}

