<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateChaptersTable extends Migration
{
    /*** Run the migrations. ** @return void */
    public function up()
    {
        Schema::create('chapters', function (Blueprint $table) {
            $table->id('chapter_id');   
            $table->string('chapter_name', 100);
            $table->bigInteger('course_id')->unsigned(); // foreign key

            // foreign key relationship
            $table->foreign('course_id')->references('course_id')->on('course')->onDelete('cascade');   

            $table->timestamps();  // created_at, updated_at 
        });
    }
    
    /*** Reverse the migrations. ** @return void */
    public function down()
    {
        Schema::dropIfExists('chapters');
    }
}




// $table->enum('class',["VI","VII","VIII"]);
            // $table->enum('curriculum',["REGULAR","ELECTIVE"]);
            // $table->string('name', 60);
            // $table->string('email', 100);
            // $table->enum('gender',["M","F","Other"])->nullable();
            // $table->text('address');
            // $table->date('dob')->nullable();
            // $table->string('password');
            // $table->boolean('status')->default(1);
            // $table->integer('points')->default(0);
