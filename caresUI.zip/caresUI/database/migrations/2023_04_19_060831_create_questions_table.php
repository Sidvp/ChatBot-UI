<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateQuestionsTable extends Migration
{
    /*** Run the migrations. ** @return void */
    public function up()
    {
        Schema::create('questions', function (Blueprint $table) {
            $table->id('question_id');  
            $table->integer('question_order');
            $table->enum('question_type',["mcq2","mcq4", "chk2", "chk4", "shortAns", "longAns","fillBlank"]);
            $table->string('question', 255)->unique();
            $table->string('image_link', 255);
            $table->string('video_link', 255);
            $table->string('option_1', 255);
            $table->string('option_2', 255);
            $table->string('option_3', 255);
            $table->string('option_4', 255);
            $table->enum('correct_option', ["1","2","3","4"]);
            $table->string('answer', 255);
            // subtopic id
            $table->bigInteger('subtopic_id')->unsigned(); // foreign key
            // foreign key relationship
            $table->foreign('subtopic_id')->references('subtopic_id')->on('subtopics')->onDelete('cascade');
            $table->timestamps();
        });
    }
    /*** Reverse the migrations. ** @return void */
    public function down()
    {
        Schema::dropIfExists('questions');
    }
}
