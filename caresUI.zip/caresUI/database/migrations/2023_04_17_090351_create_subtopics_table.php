<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSubtopicsTable extends Migration
{
    /*** Run the migrations. ** @return void */
    public function up()
    {
        Schema::create('subtopics', function (Blueprint $table) {

            $table->id('subtopic_id');   
            $table->string('subtopic_name', 100);
            $table->string('video_link', 100);
            $table->bigInteger('chapter_id')->unsigned(); // foreign key
            // foreign key relationship
            $table->foreign('chapter_id')->references('chapter_id')->on('chapters')->onDelete('cascade');   

            $table->timestamps();
        });
    }
    /*** Reverse the migrations. ** @return void */
    public function down()
    {
        Schema::dropIfExists('subtopics');
    }
}
