<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
class CreateTeachersDataTable extends Migration
{
    /*** Run the migrations. ** @return void */
    public function up()
    {
        Schema::create('teachers_data', function (Blueprint $table) {

            $table->id('teachers_id');  
            $table->string('name', 60);
            $table->string('email', 100)->unique();
            $table->string('school_name', 200);
            $table->string('username', 60);
            $table->string('password');

            $table->timestamps();  // created_at, updated_at 
        });
    }

    /*** Reverse the migrations. ** @return void */
    public function down()
    {
        Schema::dropIfExists('teachers_data');
    }
}



            // $table->enum('class',["VI","VII","VIII"]);
            // $table->enum('curriculum',["REGULAR","ELECTIVE"]);

            
            // $table->enum('gender',["M","F","Other"])->nullable();
            // $table->text('address');
            // $table->date('dob')->nullable();
            // $table->string('password');
            // $table->boolean('status')->default(1);
            // $table->integer('points')->default(0);
