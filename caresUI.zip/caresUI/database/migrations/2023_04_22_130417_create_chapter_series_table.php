<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateChapterSeriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('chapter_series', function (Blueprint $table) {
            $table->id('chapter_series_id');
            $table->text('chapter_no');
            $table->string('chapter_name');
            $table->string('image');
            $table->string('video');
            $table->string('view_button_name');

            $table->bigInteger('course_series_id')->unsigned(); // foreign key

            // foreign key relationship
            $table->foreign('course_series_id')->references('course_series_id')->on('course_series')->onDelete('cascade');   

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('chapter_series');
    }
}
