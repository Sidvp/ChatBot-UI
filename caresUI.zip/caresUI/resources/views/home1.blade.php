@extends('main1')
@push('title')
    <title>Home Page</title>
@endpush
@section('main-section')
<h1 class="text-center">Home Page</h1>    
@endsection