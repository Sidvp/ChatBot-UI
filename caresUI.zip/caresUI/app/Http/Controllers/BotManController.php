<?php

namespace App\Http\Controllers;


use BotMan\BotMan\BotMan;
use BotMan\BotMan\Messages\Conversations\MyProgressConversation;
use BotMan\BotMan\Messages\Incoming\Answer;
use Illuminate\Http\Request;
use BotMan\BotMan\Messages\Conversations\CourseConversation;
use BotMan\BotMan\Messages\Conversations\ChapterConversation;


class BotManController extends Controller
{
    public function handle(){
        $botman = app('botman');

        // $botman->hears('(Hi|Hello)', BotManController::class.'@StartConversation');


        $botman->hears('{message}', function ($bot,$message) {
            if($message == 'hi'|| $message == 'hello'){
                $bot->typesAndWaits(1);
                $bot->startConversation(new CourseConversation);
                // $bot->reply("Type learn to start with course");
                // $this->askName($bot);
            }else if($message == 'progress'){
                $bot->typesAndWaits(1);
                $bot->startConversation(new MyProgressConversation);
            }else if($message == 'chapters'){
                $bot->typesAndWaits(1);
                $bot->startConversation(new ChapterConversation);
            }
            else{
                $bot->typesAndWaits(2);
                $bot->reply("Please type 'hi' or 'hello' for testing");
            }
        });

        $botman->listen();
        
    }
}