<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    public function show(){
        return "Hello from controller";
    }

    public function showUser($id){  // pass data through url
        return "Hello from controller - $id";
    }

   
    public function loadView($name) 
    {
        // return view('users', ['user'=>$name]);
        // return view("users", ["states"=>['Goa', 'Maharashtra', 'Karnataka']], ['user'=>$user]);
        // $data=['a','b','c','d'];
        return view("users", ["state"=>['Goa', 'Maharashtra', 'Karnataka']], ['user'=>$name]);
        // return view("users", ["state"=>['Goa', 'Maharashtra', 'Karnataka']], ['user'=>$name], ['inputs'=>$data]);
        // return view("users", ["name"=>"Siddhi"]);
    }

    // Connecting to Database - method-1 - using classes
    public function dbConnection()
    {
        echo "Database connection will be established here";
        // echo DB::select("select * from users")
        return DB::select("select * from curriculum");
    }
}
