-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 18, 2023 at 12:29 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cares`
--

-- --------------------------------------------------------

--
-- Table structure for table `chapters`
--

CREATE TABLE `chapters` (
  `chapter_id` bigint(20) UNSIGNED NOT NULL,
  `chapter_name` varchar(100) NOT NULL,
  `course_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chapters`
--

INSERT INTO `chapters` (`chapter_id`, `chapter_name`, `course_id`, `created_at`, `updated_at`) VALUES
(1, 'Introduction to Raspberry Pi (RPi)/ Linux Operating System', 1, '2023-04-15 06:08:27', '2023-04-15 06:08:27'),
(2, 'Introduction to Raspberry Pi (RPi) /Linux Operating\r\nSystem (Command Line Tour)', 1, '2023-04-15 06:09:07', '2023-04-15 06:09:07'),
(3, 'Fun With Cat Sprite-Bouncing Cat', 1, '2023-04-15 06:09:55', '2023-04-15 06:09:55'),
(4, 'Fun With Cat Sprite-Controlling The Cat', 1, '2023-04-15 06:17:45', '2023-04-15 06:17:45'),
(5, 'Fun with Cat Sprite-Chasing the Mouse', 1, '2023-04-15 06:18:31', '2023-04-15 06:18:31'),
(6, 'Fun with Cat Sprite - Cat Animation', 1, '2023-04-15 06:19:10', '2023-04-15 06:19:10'),
(7, 'Fun with Cat Sprite - Sound', 1, '2023-04-15 06:19:43', '2023-04-15 06:19:43'),
(8, 'Worksheet and Excercise', 1, '2023-04-15 06:20:18', '2023-04-15 06:20:18'),
(9, 'Shapes/Drawing - Square', 1, '2023-04-15 06:20:42', '2023-04-15 06:20:42'),
(10, 'Shapes/Drawing - Square Based Pattern', 1, '2023-04-15 06:21:27', '2023-04-15 06:21:27'),
(11, 'Introduction to Vim Editor', 2, '2023-04-15 06:41:45', '2023-04-15 06:41:45'),
(12, 'Drawing Shapes using ImageMagick', 2, '2023-04-15 06:42:15', '2023-04-15 06:42:15'),
(13, 'Creating Functions in Bash and Taking Parameters using ImageMagick', 2, '2023-04-15 06:42:45', '2023-04-15 06:42:45'),
(14, 'Linux Bash Scripting for Playing Cards Generation & Animation using ImageMagick', 2, '2023-04-15 06:43:16', '2023-04-15 06:43:16'),
(15, 'Building an Analog Clock', 2, '2023-04-15 06:43:51', '2023-04-15 06:43:51'),
(16, 'Describe The Glass Using Machine Learning', 2, '2023-04-15 06:44:28', '2023-04-15 06:44:28'),
(17, 'Smart Classroom Using Machine Learning', 2, '2023-04-15 06:44:59', '2023-04-15 06:44:59'),
(18, 'Happy & Sad Face Using Machine Learning', 2, '2023-04-15 06:45:38', '2023-04-15 06:45:38'),
(19, 'Mailman Max\r\nUsing Machine Learning', 2, '2023-04-15 06:46:05', '2023-04-15 06:46:05'),
(20, 'Car or Cup Using Machine Learning', 2, '2023-04-15 06:46:35', '2023-04-15 06:46:35'),
(21, 'ABC', 3, '2023-04-16 06:12:31', '2023-04-16 06:12:31'),
(36, 'PQR', 3, '2023-04-16 23:46:46', '2023-04-16 23:46:46'),
(37, 'XYZ', 3, '2023-04-16 23:46:52', '2023-04-16 23:46:52');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `course_id` bigint(20) UNSIGNED NOT NULL,
  `class` enum('VI','VII','VIII') NOT NULL,
  `curriculum` enum('REGULAR','ELECTIVE') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`course_id`, `class`, `curriculum`, `created_at`, `updated_at`) VALUES
(1, 'VI', 'REGULAR', '2023-04-01 15:50:54', '2023-04-16 21:32:12'),
(2, 'VI', 'ELECTIVE', '2023-04-01 15:50:54', '2023-04-01 15:51:07'),
(3, 'VII', 'REGULAR', '2023-04-01 15:52:03', '2023-04-01 15:52:03'),
(4, 'VII', 'ELECTIVE', '2023-04-01 15:52:20', '2023-04-01 15:52:20'),
(5, 'VIII', 'REGULAR', '2023-04-01 15:53:06', '2023-04-01 15:53:06'),
(6, 'VIII', 'ELECTIVE', '2023-04-01 15:53:21', '2023-04-01 15:53:21');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2023_04_01_150427_create_course_table', 2),
(6, '2023_04_01_152811_create_teachers_data_table', 3),
(7, '2023_04_06_094228_create_chapters_table', 4),
(8, '2023_04_17_090351_create_subtopics_table', 5),
(9, '2023_04_17_090438_create_questions_table', 5);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `question_id` bigint(20) UNSIGNED NOT NULL,
  `question` varchar(255) NOT NULL,
  `option_1` varchar(100) NOT NULL,
  `option_2` varchar(100) NOT NULL,
  `option_3` varchar(100) NOT NULL,
  `option_4` varchar(100) NOT NULL,
  `answer` enum('1','2','3','4') NOT NULL,
  `subtopic_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subtopics`
--

CREATE TABLE `subtopics` (
  `subtopic_id` bigint(20) UNSIGNED NOT NULL,
  `subtopic_name` varchar(100) NOT NULL,
  `video_link` varchar(100) NOT NULL,
  `chapter_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `teachers_data`
--

CREATE TABLE `teachers_data` (
  `teachers_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(60) NOT NULL,
  `email` varchar(100) NOT NULL,
  `school_name` varchar(200) NOT NULL,
  `username` varchar(60) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `teachers_data`
--

INSERT INTO `teachers_data` (`teachers_id`, `name`, `email`, `school_name`, `username`, `password`, `created_at`, `updated_at`) VALUES
(2, 'Siddhi', 'parodkarsiddhi018@gmail.com', 'GHS, Siridao', 'parodkarsiddhi', '$2y$10$Z5tSbzAKQ4Nv95fcMAv/K.rjXzOWyxzXfmvslCSqe3KLjr.bq.4OG', '2023-04-04 00:18:13', '2023-04-04 00:18:13'),
(3, 'Vishakha', 'vishakha@gmail.com', 'Auxilium HS', 'vishakha', '$2y$10$ZVs737BsaMMc7DgVRyGRkOYDDIyXJb9yBqpvZW.Gi9hgsDprgEJF2', '2023-04-04 00:20:26', '2023-04-04 00:20:26'),
(4, 'Tanvi', 'tanvi@gmail.com', 'GHS, Sal', 'tanvi', '$2y$10$r3EQTZIqS0LGYERUZfu69ebSA0dLaP6sfc9qqzK20E9PBnRXE6kZa', '2023-04-04 04:13:01', '2023-04-04 04:13:01'),
(5, 'tanvi', 'tanvisawant04@gmail.com', 'GHS, Siridao', 'tanvi04', '$2y$10$1b9Cj09nNN0IC8gU05TW0.79AnxnRj7G/Q57A0PsOShCRPC4jLE.a', '2023-04-04 04:59:14', '2023-04-04 04:59:14');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chapters`
--
ALTER TABLE `chapters`
  ADD PRIMARY KEY (`chapter_id`),
  ADD KEY `chapters_course_id_foreign` (`course_id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`course_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`question_id`),
  ADD KEY `questions_subtopic_id_foreign` (`subtopic_id`);

--
-- Indexes for table `subtopics`
--
ALTER TABLE `subtopics`
  ADD PRIMARY KEY (`subtopic_id`),
  ADD KEY `subtopics_chapter_id_foreign` (`chapter_id`);

--
-- Indexes for table `teachers_data`
--
ALTER TABLE `teachers_data`
  ADD PRIMARY KEY (`teachers_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chapters`
--
ALTER TABLE `chapters`
  MODIFY `chapter_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `course_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `question_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subtopics`
--
ALTER TABLE `subtopics`
  MODIFY `subtopic_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `teachers_data`
--
ALTER TABLE `teachers_data`
  MODIFY `teachers_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `chapters`
--
ALTER TABLE `chapters`
  ADD CONSTRAINT `chapters_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`) ON DELETE CASCADE;

--
-- Constraints for table `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `questions_subtopic_id_foreign` FOREIGN KEY (`subtopic_id`) REFERENCES `subtopics` (`subtopic_id`) ON DELETE CASCADE;

--
-- Constraints for table `subtopics`
--
ALTER TABLE `subtopics`
  ADD CONSTRAINT `subtopics_chapter_id_foreign` FOREIGN KEY (`chapter_id`) REFERENCES `chapters` (`chapter_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
