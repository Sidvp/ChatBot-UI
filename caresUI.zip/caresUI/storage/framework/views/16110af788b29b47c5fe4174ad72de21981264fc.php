<!doctype html>
<html lang="en">

<head>
  <title>CARES-Goa</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS v5.2.1 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">

</head>

<body class="bg-dark align-items-center">
    <?php echo $__env->make('header1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

    <form action="<?php echo e(url('/')); ?>/login" method="POST">
        <?php echo csrf_field(); ?>

        

        <div class="container mt-4 card p-3 bg-white align-items-center">
            <br>
            <h2 class="text-center text-primary">Login</h2>
        
                <div class="form group col-md-6 required">
                    <label for="" class="form-label">Username</label><br>
                    <input type="text" name="username" id="" class="form-control" placeholder="Enter Username " aria-describedby="helpId" value="<?php echo e(old('username')); ?>">
                    
                    <span class="text-danger">
                        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </span>
                </div>

                <br>

                <div class="form group col-md-6 required">
                    <label for="" class="form-label">Password</label><br>
                    <input type="password" name="password" id="" class="form-control" placeholder="Enter Password " aria-describedby="helpId">
                    
                    <span class="text-danger">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </span>
                </div>

                
                    <br>
                    <div class="col-md-6">
                        <?php if(Session::has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(Session::get('success')); ?>

                        </div>
                        <?php endif; ?>
    
                        <?php if(Session::has('fail')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(Session::get('fail')); ?>

                        </div>
                        <?php endif; ?>
                        
                    </div>
                
    
                
            <div class="form group">
                <br>
                <button class="btn btn-primary">Submit</button>
            </div>
            <br>
            <a href="register">New User?? Register here</a>

        </div>
    </form>
</body>

</html>









    



 <?php /**PATH C:\Users\Siddhi\Desktop\Bot\caresUI\resources\views/login.blade.php ENDPATH**/ ?>