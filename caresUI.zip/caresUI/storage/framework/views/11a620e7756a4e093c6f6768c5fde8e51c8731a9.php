<!doctype html>
<html lang="en">

<head>
  <title>CARES-Goa</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS v5.2.1 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">

  <link href="https://unpkg.com/video.js@7.20.0/dist/video-js.css" rel="stylesheet">

</head>

<body class="">
    <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

    <div class="container">
        <section>
            <div class="mt-1 p-4 bg-secondary text-white text-center rounded">
                <h1><?php echo e($course->title); ?> Course</h1>
              </div>
        </section>

        <section>
          <br>
          <div class="row" style="margin-left: 0.005rem;">
            <div class="col-3 mx-auto">
              <div class="card overflow-auto" style="width: 25rem; height:400px;">
              <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card-header text-center">
                  <?php echo e($chapter->chapter_name); ?>

                </div>
                <ul class="list-group list-group-flush">
                  <li class="list-group-item">Cras justo odio</li>
                  <li class="list-group-item">Dapibus ac facilisis in</li>
                  <li class="list-group-item">Vestibulum at eros</li>
                </ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>

            <br><br>
            
            <div class="col-9">
            
            
            
           
            <video controls height="400"  autoplay muted>
              
              <source src="http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4" type="video/mp4">
              
              Your browser does not support the video tag.
            </video>
            
          </div>  
        </section>

        <section>
            <div class="row row-cols-1 row-cols-md-3 g-4 mt-4 p-4">
              <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                  <div class="card h-100">
                    
                    <img src="<?php echo e($chapter->image); ?>" height="200" class="card-img-top" alt="...">
                    <div class="card-body">
                      <h5 class="card-title text-center" style="font-size: 20px;"><?php echo e($chapter->chapter_name); ?></h5>
                      
                      
                      <br>
                      <div class="text-center">
                        <a href="<?php echo e(url('subtopics/'.$chapter->chapter_series_id)); ?>"><button type="button" class="text-center btn btn-secondary">View Chapter</button></a>
                      </div>
                    </div>
                    

                   
                    
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
        </section>

        
     
    </div>

    <script src="https://unpkg.com/video.js@7.20.0/dist/video.js"></script>
    <script src="https://unpkg.com/videojs-contrib-hls@5.15.0/es5/videojs-contrib-hls.js"></script>
</body>

</html>

<?php /**PATH C:\Users\Siddhi\Desktop\Bot\caresUI\resources\views/chapter-series.blade.php ENDPATH**/ ?>