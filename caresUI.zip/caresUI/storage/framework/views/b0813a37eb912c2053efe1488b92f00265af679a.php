<!doctype html>
<html lang="en">

<head>
  <title>CARES-Goa</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS v5.2.1 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">

</head>

<body class="bg-dark">
    <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

    <div class="container">
        
        <form action="<?php echo e(url('save-chapter')); ?>" method="POST">
        
            <?php echo csrf_field(); ?>
            <div class="container mt-4 card p-3 bg-white">
                <br>
                <h2 class="text-center text-primary">Add Chapter</h2>

                <div class="row">
                    <div class="col-md-10 mx-auto">
                        <div>
                            <h4><strong>Class: </strong> <?php echo e($class); ?></h4>
                            <h4><strong>Curriculum: </strong> <?php echo e($curriculum); ?></h4>
                        </div>
                    </div>
                </div>
                <br><br>
               
                
                    <div class="col-md-9 mx-auto text-center">
                        <?php if(Session::has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(Session::get('success')); ?>

                        </div>
                        <?php endif; ?>

                        <?php if(Session::has('fail')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(Session::get('fail')); ?>

                        </div>
                        <?php endif; ?>
                        
                    </div>
                

                <div class="row">
                    <div class="form group col-md-9 required mx-auto">

                        <input type="hidden" name="course_id" value="<?php echo e($course_id); ?>">

                        <label for="" class="form-label">Chapter Name</label><br>
                        <input type="text" name="chapter_name" id="" class="form-control" placeholder="Enter Chapter Name" aria-describedby="helpId" value="<?php echo e(old('chapter_name')); ?>">
                        
                        <span class="text-danger">
                          <?php $__errorArgs = ['chapter_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <?php echo e($message); ?>

                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </span>
                    </div>
                </div>
                
                <br>
                
                <br>
          
                <div class="form group mx-auto">
                    <br>
                    <a href="<?php echo e(url('manage-chapter/'.$course_id)); ?>"><button class="btn btn-danger me-md-2" type="button">Back</button></a>
                    <button class="btn btn-primary" type="submit">Add</button>
                </div>
                <br>
                
        
            </div>
        </form>
    </div>
</body>

</html>

<?php /**PATH C:\Users\Siddhi\Desktop\Bot\caresUI\resources\views/add-chapter.blade.php ENDPATH**/ ?>