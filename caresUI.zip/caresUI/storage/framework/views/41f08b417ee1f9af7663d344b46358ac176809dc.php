<div class="form group">
    <label for="" class="form-label">Name</label><br>
    <input type="text" name="name" id="" class="form-control" placeholder="Enter your name" aria-describedby="helpId" value="<?php echo e(old('name')); ?>">
    
    <span class="text-danger">
      <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <?php echo e($message); ?>

      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </span>
  </div>
 
  <br>

<?php /**PATH C:\Users\Siddhi\Desktop\Bot\caresUI\resources\views/components/input.blade.php ENDPATH**/ ?>