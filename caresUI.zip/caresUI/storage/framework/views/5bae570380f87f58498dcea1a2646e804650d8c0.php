
<?php $__env->startPush('title'); ?>
    <title>CARES-Goa</title>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('main-section'); ?>

<div class="container" >
    <div class="row">
        <div class="col-md-12 mx-auto">
         
                <h2>Manage Subtopic</h2> <br>  
            
                <div>
                    <h4><strong>Class: </strong> <?php echo e($course->class); ?></h4>
                    <h4><strong>Curriculum: </strong> <?php echo e($course->curriculum); ?></h4>

                    <br>

                    <h4><strong>Chapter: </strong> <?php echo e($chapter->chapter_name); ?></h4>

                </div>
                 
                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                    <a href="<?php echo e(url('add-subtopic/'.$chapter->chapter_id)); ?>" ><button class="btn btn-primary me-md-2" type="button">Add Subtopic</button></a><br><br><br>
                </div>

                <div class="col-md-12 mx-auto">
                    <?php if(Session::has('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('success')); ?>

                    </div>
                    <?php endif; ?> 

                    <?php if(Session::has('fail')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(Session::get('fail')); ?>

                    </div>
                    <?php endif; ?>
                    
                </div>
        
            
            <table class="table text-center" >
                <thead>
                    <tr>
                        <th class="text-center">#</th>
                        <th class="text-center">Subtopic Name</th>
                        <th class="text-center">Video Link</th>
                        <th class="text-center">Action</th>
                    </tr>
                </thead>


                <tbody>
                    <?php
                        $i=1;
                    ?>
                
                    <?php $__currentLoopData = $subtopics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $subtopic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            
                            <td><?php echo e($i++); ?></td>
                            <td class="text-left"><?php echo e($subtopic->subtopic_name); ?></td>
                            <td class="text-left"><a href="<?php echo e($subtopic->video_link); ?>"><?php echo e($subtopic->video_link); ?></a></td>
                            <td><a href="<?php echo e(url('edit-subtopic/'.$subtopic->subtopic_id)); ?>" class="btn btn-primary me-md-4">Edit</a><a href="<?php echo e(url('delete-subtopic/'.$subtopic->subtopic_id)); ?>" class="btn btn-danger">Delete</a> </td>
                        </tr>         
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </tbody>
            </table>  
            

             <div class="form group mx-auto">
                <br>
                <a href="<?php echo e(url('select-chapter-for-subtopic')); ?>"><button class="btn btn-primary me-md-2" type="button">Back</button></a>
            </div>
            
        </div>
    </div>
</div> 




<?php $__env->stopSection(); ?> 

        
    
                        
                        
        

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Siddhi\Desktop\Bot\caresUI\resources\views/manage-subtopic.blade.php ENDPATH**/ ?>