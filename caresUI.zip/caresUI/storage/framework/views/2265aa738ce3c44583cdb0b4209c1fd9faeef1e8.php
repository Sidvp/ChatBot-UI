
<?php $__env->startPush('title'); ?>
    <title>Home Page</title>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('main-section'); ?>
<h1 class="text-center">Home Page</h1>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Siddhi\Desktop\Bot\caresUI\resources\views/home.blade.php ENDPATH**/ ?>