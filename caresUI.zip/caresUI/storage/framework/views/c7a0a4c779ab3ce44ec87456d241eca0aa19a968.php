<!doctype html>
<html lang="en">

<head>
  <title>CARES-Goa</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS v5.2.1 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">

</head>

<body class="bg-dark">
    <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

    <div class="container">
        
        <form action="<?php echo e(url('update-subtopic')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="container mt-4 card p-3 bg-white">
                <br>
                <h2 class="text-center text-primary">Edit Subtopic</h2>

                <?php
                    $course_id = $course->course_id;
                    $class = $course->class;
                    $curriculum = $course->curriculum;    
                    $chapter_id = $chapter->chapter_id;
                    $chapter_name = $chapter->chapter_name;                
                ?>


                <div class="row">
                    <div class="col-md-10 mx-auto">
                        <div>
                            <h4><strong>Class: </strong> <?php echo e($class); ?></h4>
                            <h4><strong>Curriculum: </strong> <?php echo e($curriculum); ?></h4>
                            <br>
                            <h4><strong>Chapter: </strong> <?php echo e($chapter_name); ?></h4>
                        </div>
                    </div>
                </div>
                <br><br>
               
                
                    <div class="col-md-9 mx-auto text-center">
                        <?php if(Session::has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(Session::get('success')); ?>

                        </div>
                        <?php endif; ?>

                        <?php if(Session::has('fail')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(Session::get('fail')); ?>

                        </div>
                        <?php endif; ?>
                        
                    </div>
                

                <div class="row">
                    <div class="form group col-md-9 required mx-auto">

                        <input type="hidden" name="course_id" value="<?php echo e($course_id); ?>">
                        <input type="hidden" name="chapter_id" value="<?php echo e($chapter_id); ?>">
                        <input type="hidden" name="subtopic_id" value="<?php echo e($data->subtopic_id); ?>">


                        <label for="" class="form-label">Subtopic Name</label><br>
                        <input type="text" name="subtopic_name" id="" class="form-control" placeholder="Enter Subtopic Name" aria-describedby="helpId" value="<?php echo e($data->subtopic_name); ?>">
                        
                        <span class="text-danger">
                          <?php $__errorArgs = ['subtopic_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <?php echo e($message); ?>

                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </span>

                      <br>
                      <label for="" class="form-label">Video Link</label><br>
                        <input type="text" name="video_link" id="" class="form-control" placeholder="Enter Video Link" aria-describedby="helpId" value="<?php echo e($data->video_link); ?>">
                        
                        <span class="text-danger">
                          <?php $__errorArgs = ['video_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <?php echo e($message); ?>

                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </span>
                    </div>
                </div>
                
                
                <br>
                
                <br>
          
                <div class="form group mx-auto">
                    <br>
                    <a href="<?php echo e(url('manage-chapter/'.$course_id)); ?>"><button class="btn btn-danger me-md-2" type="button">Back</button></a>
                    <button class="btn btn-primary" type="submit">Update</button>
                </div>
                <br>
                
        
            </div>
        </form>
    </div>
</body>

</html>

<?php /**PATH C:\Users\Siddhi\Desktop\Bot\caresUI\resources\views/edit-subtopic.blade.php ENDPATH**/ ?>