
<?php $__env->startPush('title'); ?>
    <title>CARES-Goa</title>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('main-section'); ?>

<div class="container" >
    <div class="row">
        <div class="col-md-12 mx-auto">
         
                <h2>Manage Questions</h2> <br>  
            
                <div>
                    <h4><strong>Class: </strong> <?php echo e($course->class); ?></h4>
                    <h4><strong>Curriculum: </strong> <?php echo e($course->curriculum); ?></h4>

                    <br>

                    <h4><strong>Chapter: </strong> <?php echo e($chapter->chapter_name); ?></h4>

                    <br>

                    <h4><strong>Subtopic: </strong> <?php echo e($subtopic->subtopic_name); ?></h4>

                </div>
                 
                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                    <a href="<?php echo e(url('add-question/'.$subtopic->subtopic_id)); ?>" ><button class="btn btn-primary me-md-2" type="button">Add Question</button></a><br><br><br>
                </div>

                <div class="col-md-12 mx-auto">
                    <?php if(Session::has('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('success')); ?>

                    </div>
                    <?php endif; ?> 

                    <?php if(Session::has('fail')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(Session::get('fail')); ?>

                    </div>
                    <?php endif; ?>
                    
                </div>
        
            <input type="hidden" name="course_id" value="<?php echo e($course->course_id); ?>">
            <input type="hidden" name="chapter_id" value="<?php echo e($chapter->chapter_id); ?>">
            <input type="hidden" name="subtopic_id" value="<?php echo e($subtopic->subtopic_id); ?>">
            
            <table class="table text-center" >
                <thead>
                    <tr>
                        <th class="text-center">#</th>
                        <th class="text-center">Question Type</th>
                        
                        <th class="text-center">Question</th>
                        <th class="text-center">Image Link</th>
                        <th class="text-center">Video Link</th>
                        <th class="text-center">Option 1</th>
                        <th class="text-center">Option 2</th>
                        <th class="text-center">Option 3</th>
                        <th class="text-center">Option 4</th>
                        <th class="text-center">Correct Option</th>
                        <th class="text-center">Answer</th>
                        <th class="text-center">Action</th>
                        
                    </tr>
                </thead>

 
                <tbody>
                    <?php
                        $i=1;
                    ?>
                
                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            
                            <td><?php echo e($i++); ?></td>
                            <td class="text-left"><?php echo e($question->question_type); ?></td>
                            <td class="text-left"><?php echo e($question->question); ?></td>
                            <td class="text-left"><a href="<?php echo e($question->image_link); ?>"><?php echo e($question->image_link); ?></a></td>
                            <td class="text-left"><a href="<?php echo e($question->video_link); ?>"><?php echo e($question->video_link); ?></a></td>

                            <td class="text-left"><?php echo e($question->option_1); ?></td>
                            <td class="text-left"><?php echo e($question->option_2); ?></td>
                            <td class="text-left"><?php echo e($question->option_3); ?></td>
                            <td class="text-left"><?php echo e($question->option_4); ?></td>
                            <td class="text-left"><?php echo e($question->correct_option); ?></td>
                            <td class="text-left"><?php echo e($question->answer); ?></td>
                            
                            
                            <td><a href="<?php echo e(url('edit-question/'.$question->question_id)); ?>" class="btn btn-primary me-md-4">Edit</a><a href="<?php echo e(url('delete-question/'.$question->question_id)); ?>" class="btn btn-danger">Delete</a> </td>
                        </tr>         
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </tbody>
            </table>  
            

             <div class="form group mx-auto">
                <br>
                <a href="<?php echo e(url('select-subtopic-for-question')); ?>"><button class="btn btn-danger me-md-2" type="button">Back</button></a>
            </div>
            
        </div>
    </div>
</div> 




<?php $__env->stopSection(); ?> 

        
    
                        
                        
        

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Siddhi\Desktop\Bot\caresUI\resources\views/manage-question.blade.php ENDPATH**/ ?>