<!doctype html>
<html lang="en">

<head>
  <title>Select Course</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS v5.2.1 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">

    
</head>

<body class="bg-dark">
  
  <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;  <!-- View -->


    <div class="container">

      
        <div class="row">
        <div class="col-md-12 mx-auto">
        <form method="post" action="<?php echo e(url('identify-course-for-subtopic')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group mt-4 card p-3 bg-white">
                
                    <br>
                <h2 class="text-center text-primary">Select Course</h2><br><br>
              
                
                    <div class="col-md-5 mx-auto">
                        <?php if(Session::has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(Session::get('success')); ?>

                        </div>
                        <?php endif; ?> 

                        <?php if(Session::has('fail')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(Session::get('fail')); ?>

                        </div>
                        <?php endif; ?>
                        

                         
                    </div>
             

                <div class="row">
                    <div class="form-group col-md-5 required mx-auto">
                      <div class="input-group">
                        <label for="class" class="" style="">Class</label>

                        

                          <select class="form-control required" name="class" id="class" style="">
                            <option selected disabled value="">Select Class</option>
                            
                            
                            
                            <option value="VI" <?php if(old('class') == "VI"): ?> <?php echo e('selected'); ?> <?php endif; ?>>VI</option>
                            <option value="VII" <?php if(old('class') == "VII"): ?> <?php echo e('selected'); ?> <?php endif; ?>>VII</option>
                            <option value="VIII" <?php if(old('class') == "VIII"): ?> <?php echo e('selected'); ?> <?php endif; ?>>VIII</option>
                          </select>
                          <br>
                          <span class="text-danger">
                            <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </span>
                    </div>
                    </div>
                </div>
                
                <br>
                
               
                <div class="row">
                  <div class="form-group col-md-5 required mx-auto">
                    <div class="input-group">
                      <label for="class" class="" style="">Curriculum</label>

                      
                       
                        <select class="form-control required" name="curriculum" id="curriculum" style="">
                          <option selected disabled value="">Select Curriculum</option>
                          
                          
                          <option value="REGULAR" <?php if(old('curriculum') == "REGULAR"): ?> <?php echo e('selected'); ?> <?php endif; ?>>REGULAR</option>
                          <option value="ELECTIVE" <?php if(old('curriculum') == "ELECTIVE"): ?> <?php echo e('selected'); ?> <?php endif; ?>>ELECTIVE</option>
                        </select>
                      <br>
                  
                      <span class="text-danger">
                        <?php $__errorArgs = ['curriculum'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </span>
                  </div>
                  </div>
              </div>
                
                <br>
                
               
                <div class="form group mx-auto">
                    <br>
                    <a href="<?php echo e(url('/dashboard')); ?>"><button class="btn btn-danger me-md-2" type="button">Back</button></a>
                    <button class="btn btn-primary me-md-2" type="submit">Next</button>      
                </div>
              </div>
                </div>
        
            
        </form>
    </div>
  </div>
    </div>


  <!-- Bootstrap JavaScript Libraries -->

  


  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
    integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
  </script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
    integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous">
  </script>

  
</body>

</html>

<?php /**PATH C:\Users\Siddhi\Desktop\Bot\caresUI\resources\views/select-course-for-subtopic.blade.php ENDPATH**/ ?>