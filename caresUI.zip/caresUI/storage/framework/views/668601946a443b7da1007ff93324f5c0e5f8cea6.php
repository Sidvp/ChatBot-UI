<div>
    <!-- I have not failed. I've just found 10,000 ways that won't work. - Thomas Edison -->
    <!-- 
        Component - code to be reused.
        E.g.: Header, Footer, Sign-up button

        To make component:
        php artisan make:component <component-name>

        Two files are created: 
        1. views -> components -> header.blade.php  (HTML File)
        2. app -> View -> Components -> Header.php (PHP/ dynamic code)


    -->
    <!-- <h1>Header Component</h1> -->
    <h1><?php echo e($title); ?> - Header Component</h1>
</div><?php /**PATH C:\Users\Siddhi\Desktop\Bot\caresUI\resources\views/components/header.blade.php ENDPATH**/ ?>