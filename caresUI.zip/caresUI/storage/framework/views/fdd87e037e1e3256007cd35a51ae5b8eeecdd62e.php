<div>
    <!-- If you do not have a consistent goal in life, you can not live it in a consistent way. - Marcus Aurelius -->
    <h1><?php echo e($title); ?> - Footer Component</h1>
</div><?php /**PATH C:\Users\Siddhi\Desktop\Bot\caresUI\resources\views/components/footer.blade.php ENDPATH**/ ?>