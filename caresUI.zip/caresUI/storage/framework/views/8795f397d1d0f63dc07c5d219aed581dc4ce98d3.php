<?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, ['componentName' => 'Users']); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>
<h1>User Page</h1>
<h2>Welcome <?php echo e($user ?? "Guest"); ?></h2>
<?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, ['componentName' => 'Users']); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<!-- 
URL Generation - using 'url' class
- to get query parameters: eg: ?age=30
- to find current page
- to submit the form on specific route
- to find/get last visited page

1. Current URL
2. Full URL
3. Previous URL

Reference:
URL class in Laravel: https://laravel.com/api/9.x/Illuminate/Support/Facades/URL.html
-->



<h2><?php echo e(10+20); ?></h2>  <!-- Expression -->

<h2><?php echo e(count($state)); ?></h2>

<!-- If loop -->
<?php if($state[0]=="Goa"): ?>
<h2>Welcome to <?php echo e($state[0]); ?></h2>
<?php endif; ?>

<!-- If-else loop -->
<?php if($user=="Siddhi"): ?>
<h2>Welcome <?php echo e($user); ?></h2>
<?php else: ?>
<h2>Welcome Guest</h2>
<?php endif; ?>


<!-- If-elseif loop -->
<?php if($user=="Siddhi"): ?>
<h2>Welcome to <?php echo e($user); ?></h2>
<?php elseif($user=="Tanvi"): ?>
<h2>Hi <?php echo e($user); ?></h2>
<?php else: ?>
<h2>Hi Unknown</h2>
<?php endif; ?>

<!-- For loop -->
<?php for($i=0; $i<10; $i++): ?>
<h4><?php echo e($i); ?></h4>
<?php endfor; ?>

<!-- Foreach loop -->
<?php $__currentLoopData = $state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h6><?php echo e($s); ?></h6>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<!-- csrf token function - to protect data from unauthorized users -->
<?php echo csrf_field(); ?> <!-- Token generated in hidden field -->

<!-- Include view -->
<?php echo $__env->make('innerPage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<!-- Include PHP in JS -->
<script>
    var data=<?php echo json_encode($state, 15, 512) ?>;
    // console.warn(data);
    console.log(data);
    // console.warn(data[0]);
    console.log(data[0]);
</script><?php /**PATH C:\Users\Siddhi\Desktop\Bot\caresUI\resources\views/users.blade.php ENDPATH**/ ?>