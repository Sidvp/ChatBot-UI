
<?php $__env->startPush('title'); ?>
    <title>CARES-Goa</title>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('main-section'); ?>

<div class="container" >
    <div class="row">
        <div class="col-md-12 mx-auto">
            <form method="post" action="<?php echo e(url('identify-chapter-for-question')); ?>">
                <?php echo csrf_field(); ?>
            <div class="form-group mt-4 card p-3 bg-white">
         
                <h2 class="text-center">Select Chapter</h2> <br>  
            
                <div style="margin-left: 50px; margin-right: 50px;">
                    <h4><strong>Class: </strong> <?php echo e($course->class); ?></h4>
                    <h4><strong>Curriculum: </strong> <?php echo e($course->curriculum); ?></h4>
                </div>
                 
                <br><br>

                <div class="col-md-12 mx-auto">
                    <?php if(Session::has('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('success')); ?>

                    </div>
                    <?php endif; ?> 

                    <?php if(Session::has('fail')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(Session::get('fail')); ?>

                    </div>
                    <?php endif; ?>
                    
                </div>

                <input type="hidden" name="course_id" value="<?php echo e($course->course_id); ?>">
                

                <select class="form-control required" name="chapter_name" id="class" style="margin: auto; width:1000px;">
                    <option selected disabled value="">Select Chapter</option>
                    
                    <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <option value="<?php echo e($chapter['chapter_name']); ?>"><?php echo e($chapter['chapter_name']); ?></option>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

           
                <br><br>

                <div class="form-group mx-auto">
                    <br>
                    <a href="<?php echo e(url('/select-course-for-question')); ?>"><button class="btn btn-danger me-md-2" type="button">Back</button></a>
                    <button class="btn btn-primary me-md-2" type="submit">Next</button>      
                </div>
             
        </div>
        
    </div>
</div> 




<?php $__env->stopSection(); ?> 

        
    
                        
                        
        

<?php echo $__env->make('main2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Siddhi\Desktop\Bot\caresUI\resources\views/select-chapter-for-question.blade.php ENDPATH**/ ?>