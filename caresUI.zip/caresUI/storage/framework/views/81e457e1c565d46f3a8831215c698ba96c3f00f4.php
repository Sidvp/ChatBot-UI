<!doctype html>
<html lang="en">

<head>
  <title>CARES-Goa</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS v5.2.1 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">

    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
</head>

<body class="bg-dark">
    <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

    <div class="container" style="margin-bottom: 40px;">
        
        <form action="<?php echo e(url('save-question')); ?>" method="POST">
        
            <?php echo csrf_field(); ?>
            <div class="container card p-3 bg-white">
                <br>
                <h2 class="text-center text-primary">Add Question</h2>

                <div class="row">
                    <div class="col-md-10 mx-auto">
                        <div>
                            <h4><strong>Class: </strong> <?php echo e($course->class); ?></h4>
                            <h4><strong>Curriculum: </strong> <?php echo e($course->curriculum); ?></h4>

                            <br>

                            <h4><strong>Chapter: </strong> <?php echo e($chapter->chapter_name); ?></h4>
                            <br>
                            <h4><strong>Subtopic: </strong> <?php echo e($subtopic->subtopic_name); ?></h4>
                        </div>
                    </div>
                </div>
                <br><br>
               
                
                <div class="col-md-9 mx-auto text-center">
                        <?php if(Session::has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(Session::get('success')); ?>

                        </div>
                        <?php endif; ?>

                        <?php if(Session::has('fail')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(Session::get('fail')); ?>

                        </div>
                        <?php endif; ?>
                        
                    </div>
                

                <div class="row">
                    <div class="form group col-md-10 required mx-auto">

                        <input type="hidden" name="course_id" value="<?php echo e($course->course_id); ?>">
                        <input type="hidden" name="chapter_id" value="<?php echo e($chapter->chapter_id); ?>">
                        <input type="hidden" name="subtopic_id" value="<?php echo e($subtopic->subtopic_id); ?>">

                        <div>
                            <label for="" class="form-label">Question Type</label><br>
                            <select name="question_type" id="question_type" onchange="changeStatus()" required style="width:180px; height:30px;">
                                <option selected disabled value="">Select Question Type</option>
                               
                                <option value="mcq2" <?php if(old('question_type') == "mcq2"): ?> <?php echo e('selected'); ?> <?php endif; ?>>2 Options MCQ</option>
                                <option value="mcq4" <?php if(old('question_type') == "mcq4"): ?> <?php echo e('selected'); ?> <?php endif; ?>>4 Options MCQ</option>
                                <option value="chk2" <?php if(old('question_type') == "chk2"): ?> <?php echo e('selected'); ?> <?php endif; ?>>2 Options Checkboxes</option>
                                <option value="chk4" <?php if(old('question_type') == "chk4"): ?> <?php echo e('selected'); ?> <?php endif; ?>>4 Options Checkboxes</option>
                                <option value="fillBlank" <?php if(old('question_type') == "fillBlank"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Fill in the blanks</option>
                                
                                <option value="shortAns" <?php if(old('question_type') == "shortAns"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Short Answer</option>
                                <option value="longAns" <?php if(old('question_type') == "longAns"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Long Answer</option>
                                
                            </select>
                            <span class="text-danger">
                                <?php $__errorArgs = ['question_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </span>
      
                            &nbsp;&nbsp;
                            <button type="button" class="btn btn-primary qtypebtn" style="" id="type_selected">Select</button>
                            
    
                        </div>

                        <div class="questionbox col-md-8">
                            <br><br>
                            <label for="" id="quest1" class="form-label" style="display:none">Enter Question</label>
                            <input type="text" id="quest" name="quest" placeholder="Enter Question " style="width:500px;display:none">
                            <span class="text-danger">
                                <?php $__errorArgs = ['quest'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </span>
                            <br><br>

                            <label for="" id="quest_img1" class="form-label" style="display:none">Image Link (Optional)</label>
                            <input type="text" id="quest_img" name="quest_img" placeholder="Enter Question " style="width:500px;display:none">
                            <span class="text-danger">
                                <?php $__errorArgs = ['quest_img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </span>
                            <br><br>

                            <label for="" id="quest_video1" class="form-label" style="display:none">Video Link (Optional)</label>
                            <input type="text" id="quest_video" name="quest_video" placeholder="Enter Question " style="width:500px;display:none">
                            <?php $__errorArgs = ['quest_video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                
                        
                            
                            <div id="mcq2" class="qt" style="display: none">
                                
                                <br><br>
                                <label for="" class="form-label">Enter Options</label><br>
                                <div class="option2">
                                    <input type="text" name="opt2_1" placeholder="Enter Option 1 ">
                                    <?php $__errorArgs = ['opt2_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <br><br>

                                    <input type="text" name="opt2_2" placeholder="Enter Option 2 ">
                                    <?php $__errorArgs = ['opt2_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <br><br>
                                <label for="" class="form-label">Enter Correct Option No.</label><br>
                                <select type="number" name="correctOpt2" placeholder="Enter Correct Option No." style="height:30px">
                                    <option selected disabled value="">Select Correct Option  </option>
                                    <option value="1" <?php if(old('correctOpt2') == "1"): ?> <?php echo e('selected'); ?> <?php endif; ?>>1</option>
                                    <option value="2" <?php if(old('correctOpt2') == "2"): ?> <?php echo e('selected'); ?> <?php endif; ?>>2</option>
                                </select>
                                <?php $__errorArgs = ['correctOpt2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                <br><br><br>
                                <button type="submit" class="btn btn-primary">Add Question</button>
                                <br><br><br>
                            </div>
                            
                
                            
                            <div id="mcq4" class="qt" style="display: none">
                                
                                <br><br>
                                <label for="" class="form-label">Enter Options</label><br>
                                <div class="option4">
                                    <input type="text" name="opt4_1" placeholder="Enter your Option 1 ">
                                    <?php $__errorArgs = ['opt4_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <br><br>
                                    <input type="text" name="opt4_2" placeholder="Enter your Option 2 ">
                                    <?php $__errorArgs = ['opt4_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <br><br>
                                    <input type="text" name="opt4_3" placeholder="Enter your Option 3 ">
                                    <?php $__errorArgs = ['opt4_3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <br><br>
                                    <input type="text" name="opt4_4" placeholder="Enter your Option 4 ">
                                    <?php $__errorArgs = ['opt4_4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <br><br>
                                <label for="" class="form-label">Enter Correct Option No.</label><br>
                                <select type="number" name="correctOpt4" placeholder="Enter Correct Option No." style="height:30px">
                                    <option selected disabled value="">Select Correct Option  </option>
                                    <option value="1" <?php if(old('correctOpt4') == "1"): ?> <?php echo e('selected'); ?> <?php endif; ?>>1</option>
                                    <option value="2" <?php if(old('correctOpt4') == "2"): ?> <?php echo e('selected'); ?> <?php endif; ?>>2</option>
                                    <option value="3" <?php if(old('correctOpt4') == "3"): ?> <?php echo e('selected'); ?> <?php endif; ?>>3</option>
                                    <option value="4" <?php if(old('correctOpt4') == "4"): ?> <?php echo e('selected'); ?> <?php endif; ?>>4</option>
                                </select>
                                <?php $__errorArgs = ['correctOpt4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <br><br><br>
                                <button type="submit" class="btn btn-primary">Add Question</button>
                                <br><br><br>
                            </div>
                            
                
                            
                            <div id="chk2" class="qt" style="display: none">
                                <br><br>
                                
                                <label for="" class="form-label">Enter Options</label><br>
                                <div class="chkoption">
                                    <input type="text" name="chkopt2_1" placeholder="Enter your Option 1 ">
                                    <?php $__errorArgs = ['chkopt2_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <br><br>
                                    <input type="text" name="chkopt2_2" placeholder="Enter your Option 2 ">
                                    <?php $__errorArgs = ['chkopt2_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <br><br>
                              
                                <label for="">Please select the correct answer(s): </label>
                                
                                <br>
                                
                                <select id="correctchkopt2" name="correctchkopt2[]" class="form-select w-25" style="height:45px; text-align: center; font-size:14px;" multiple>
                                    <option value="1" <?php if(old('correctchkopt2') == "1"): ?> <?php echo e('selected'); ?> <?php endif; ?>>1</option>
                                    <option value="2" <?php if(old('correctchkopt2') == "2"): ?> <?php echo e('selected'); ?> <?php endif; ?>>2</option>
                                </select>
                                <?php $__errorArgs = ['correctchkopt2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <br>
                                <label for="correctchkopt2" class="text-danger">NOTE:- To select multiple press and hold ctrl and click the option</label>
                                
                                <br><br><br>
                                <button type="submit" class="btn btn-primary">Add Question</button>
                                <br><br><br>
                            </div>
                            
                
                            
                            <div id="chk4" class="qt" style="display: none">
                                
                                <br><br>
                                <label for="" class="form-label">Enter Options</label><br>
                                
                                <div class="chkoption">
                                    <input type="text" name="chkopt4_1" placeholder="Enter your Option 1 ">
                                    <?php $__errorArgs = ['chkopt4_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <br><br>
                                    <input type="text" name="chkopt4_2" placeholder="Enter your Option 2 ">
                                    <?php $__errorArgs = ['chkopt4_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <br><br>
                                    <input type="text" name="chkopt4_3" placeholder="Enter your Option 3 ">
                                    <?php $__errorArgs = ['chkopt4_3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <br><br>
                                    <input type="text" name="chkopt4_4" placeholder="Enter your Option 4 ">
                                    <?php $__errorArgs = ['chkopt4_4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
                                </div>
                                <br><br>
                                
                                <label for="">Please select the correct answer(s): </label>
                                <br>
                                <select id="correctchkopt4" name="correctchkopt4[]" class="form-select w-25" style="height:80px; text-align: center; font-size:14px;" multiple>
                                    <option value="1" <?php if(old('correctchkopt4') == "1"): ?> <?php echo e('selected'); ?> <?php endif; ?>>1</option>
                                    <option value="2" <?php if(old('correctchkopt4') == "2"): ?> <?php echo e('selected'); ?> <?php endif; ?>>2</option>
                                    <option value="3" <?php if(old('correctchkopt4') == "3"): ?> <?php echo e('selected'); ?> <?php endif; ?>>3</option>
                                    <option value="4" <?php if(old('correctchkopt4') == "4"): ?> <?php echo e('selected'); ?> <?php endif; ?>>4</option>
                                </select>
                                <?php $__errorArgs = ['correctchkopt4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <br>
                                <label for="correctchkopt4" class="text-danger">NOTE:- To select multiple press and hold ctrl and click the option</label>
                                <br><br><br>
                                <button type="submit" class="btn btn-primary">Add Question</button>
                                <br><br><br>
                            </div>
                            
                
                            
                           
                            <div id="shortAns" class="qt" style="display: none">
                                <br><br>
                                <label for="" id="" class="form-label">Enter Answer</label>
                                <input type="text" id="" name="answer1" placeholder="Enter Answer " style="width:500px; height: 50px;">
                                <?php $__errorArgs = ['answer1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <br><br>
                                <button type="submit" class="btn btn-primary">Add Question</button>
                                <br><br><br>
                            </div>
                            
                                
                            <div id="longAns" class="qt" style="display: none">
                                <br><br>
                                <label for="" id="" class="form-label">Enter Answer</label>
                                <input type="text" id="" name="answer2" placeholder="Enter Answer " style="width:500px; height: 50px;">
                                <?php $__errorArgs = ['answer2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <br><br>
                                <button type="submit" class="btn btn-primary">Add Question</button>
                                <br><br><br>
                            </div>
                     

                            <div id="fillBlank" class="qt" style="display: none">
                                <br><br>
                                <label for="" id="" class="form-label">Enter Answer</label><br>
                                <input type="text" id="" name="answer" placeholder="Enter Answer " style="width:180px;">
                                <?php $__errorArgs = ['answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <br><br>
                                <button type="submit" class="btn btn-primary">Add Question</button>
                                <br><br><br>
                            </div>
                        </div>
                    </div>
                </div>
            
                <div class="form group text-center">
                    <a href="<?php echo e(url('manage-question/'.$subtopic_id)); ?>"><button class="btn btn-danger me-md-2" type="button">Back</button></a>
                    <br><br>
                </div>
        </form>
    </div>

    <script>
        let qtbox = document.querySelector(".questionbox")
        let qtypebtn = document.querySelector(".qtypebtn")
        let qtype = document.querySelector("#question_type")
    
        let qt = document.querySelectorAll(".qt")
        let shorttextquest = document.querySelector("#shortAns")
        let fillBlankquest = document.querySelector("#fillBlank")
        let longtextquest = document.querySelector("#longAns")
    
        let mcqquest2 = document.querySelector("#mcq2")
        let mcqquest4 = document.querySelector("#mcq4")
    
        let chkquest2 = document.querySelector("#chk2")
        let chkquest4 = document.querySelector("#chk4")
    
        let inpquest = document.querySelector("#quest")
        let inpquest1 = document.querySelector("#quest1")

        let inpquest_img = document.querySelector("#quest_img")
        let inpquest_img1 = document.querySelector("#quest_img1")

        let inpquest_video = document.querySelector("#quest_video")
        let inpquest_video1 = document.querySelector("#quest_video1")
        
        qtypebtn.onclick = ()=>{
    
            console.log(qtype.value)
            inpquest.style.display="block"
            inpquest1.style.display="block"

            inpquest_img.style.display="block"
            inpquest_img1.style.display="block"

            inpquest_video.style.display="block"
            inpquest_video1.style.display="block"
    
            qt.forEach((ele)=>{
                ele.style.display="none"
            })
    
            if(qtype.value === "shortAns"){
    
                shorttextquest.style.display="block"
    
            }else if (qtype.value === "longAns"){
    
                longtextquest.style.display="block"

            }
            else if(qtype.value === "mcq2"){
    
                mcqquest2.style.display="block"
    
            }else if(qtype.value === "mcq4"){
    
                mcqquest4.style.display="block"
    
            }else if(qtype.value === "chk2"){
    
                chkquest2.style.display="block"
    
            }else if(qtype.value === "chk4"){
    
                chkquest4.style.display="block"
    
            }
            else if(qtype.value === "fillBlank"){
    
                fillBlankquest.style.display="block"

            }else{
                alert("Please select valid option");
            }
        }
    
        
        let gobtn = document.querySelector("#gobtn");

        let quest = document.querySelector("#quest");
        let quest1 = document.querySelector("#quest1");

        let quest_video = document.querySelector("#quest_video");
        let quest_video1 = document.querySelector("#quest_video1");

        let quest_img = document.querySelector("#quest_img");
        let quest_img1 = document.querySelector("#quest_img1");

        
    
   
    </script>
</body>

</html>

<?php /**PATH C:\Users\Siddhi\Desktop\Bot\caresUI\resources\views/add-question.blade.php ENDPATH**/ ?>