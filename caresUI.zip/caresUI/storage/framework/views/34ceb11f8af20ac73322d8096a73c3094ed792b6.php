
<?php $__env->startPush('title'); ?>
    <title>CARES-Goa</title>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('main-section'); ?>
<h1 style="margin-left:90px;">Courses</h1>    

<div class="container" style="margin-left:150px;">
    <div class="row">
        <div class="col-md-6 ">
    <br>
    
        <table class="table text-center">
            <thead>
                <tr>
                    <th class="text-center">#</th>
                    <th class="text-center">Class</th>
                    <th class="text-center">Curriculum</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $i=1; 
                ?>

                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index =>$d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        
                        <td><?php echo e($index + $data->firstItem()); ?></td>
                        <td><?php echo e($d->class); ?></td>
                        <td><?php echo e($d->curriculum); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </tbody>
        </table>
        <div class="row">
            <div class="col-7">
                Showing <?php echo e($data->firstItem()); ?> - <?php echo e($data->lastItem()); ?> of <?php echo e($data->total()); ?>

            </div>
            <div class="col-5 mx-auto">
                <?php echo e($data->links()); ?>

            </div>
        </div>
    </div>

    

     <br><br>
     

    
    </div>
</div>

<br><br>

<div class="d-grid gap-2 d-md-flex justify-content-md-start" style="margin-left: 100px;">
    <a href="<?php echo e(url('/dashboard')); ?>"><button class="btn btn-primary me-md-2" type="button">Back</button></a>
    
    
</div>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Siddhi\Desktop\Bot\caresUI\resources\views/view-course.blade.php ENDPATH**/ ?>