
<?php $__env->startPush('title'); ?>
    <title>CARES-Goa</title>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('main-section'); ?>
<h1 class="text-center">Add Questions</h1>    


        
    
                        
                        
        
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Siddhi\Desktop\Bot\caresUI\resources\views/add-questions.blade.php ENDPATH**/ ?>